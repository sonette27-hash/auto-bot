#!/usr/bin/env python
# -*- coding: utf-8 -*-

##
# IbPy package root.
#
##

__version__ = '0.8.0'


